# drawer_demo

A Flutter app that demonstrates how to implement the good old NavigationDrawer present in Android Native.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
